// script.js

document.getElementById("carbonForm").addEventListener("submit", function(event) {
    event.preventDefault();

    // Get input values
    const carMiles = parseFloat(document.getElementById("carMiles").value);
    const electricityKWh = parseFloat(document.getElementById("electricityKWh").value);
    const wasteKg = parseFloat(document.getElementById("wasteKg").value);

    // Conversion factors (source: approximate averages)
    const carCO2PerMile = 0.411; // kg CO2 per mile (average for a car)
    const electricityCO2PerKWh = 0.92; // kg CO2 per kWh (depends on energy mix)
    const wasteCO2PerKg = 0.5; // kg CO2 per kg of waste (depending on waste type)

    // Calculate the carbon footprint
    const carFootprint = carMiles * carCO2PerMile;  // Carbon footprint from car miles
    const electricityFootprint = electricityKWh * electricityCO2PerKWh / 30;  // Monthly to daily conversion
    const wasteFootprint = wasteKg * wasteCO2PerKg / 7;  // Weekly to daily conversion

    // Total carbon footprint
    const totalFootprint = carFootprint + electricityFootprint + wasteFootprint;

    // Display the result
    document.getElementById("carbonResult").innerText = totalFootprint.toFixed(2);
});
